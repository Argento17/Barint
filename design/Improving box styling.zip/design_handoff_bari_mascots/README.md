# Handoff: Bari Mascots — Newsletter Signup & Comparisons Section

## Overview
Two Bari surfaces that introduce the brand mascots into live UI:

- **2b — Newsletter Signup** ("Little Olive, the host"): a centered marketing card inviting the user to subscribe to Bari updates. The olive mascot stands beside the CTA.
- **2d — "Comparisons from the shelf" section** ("Curious Leaf hooks the section"): a section header + a 2×2 grid of comparison cards on the homepage/blog. The leaf mascot (holding a magnifier) anchors the heading.

Both are **RTL / Hebrew-first**. All copy below is the exact Hebrew used in the reference.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing the intended look, not production code to copy directly. The task is to **recreate these designs in the target codebase** (the Bari production app is Next.js / React with a shadcn-based token system; fonts are loaded via `next/font`) using its established components and patterns. If you are building outside that app, pick the framework that fits the project and implement there. Do not ship the reference PNGs or any prototype HTML as-is.

Bari already has a design-token layer. Map the tokens listed here to the codebase's existing CSS variables (they match the names in `tokens/colors_and_type.css`) rather than hardcoding hex where a token exists.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, and copy are final and specified below. Recreate pixel-faithfully using Bari's existing component library (buttons, inputs, cards, badges) — the goal is visual parity, implemented with real components, not a clone of the prototype markup.

---

## Screen 2b — Newsletter Signup

**Purpose:** convert a reader into a newsletter subscriber. One email field + one CTA, framed warmly by the olive mascot.

**Layout**
- Full-bleed section on the warm canvas (`--canvas #F7F7F2`); the card is centered with generous outer padding.
- **Card:** max-width ≈ 1040px, centered. Background `--surface #FFFFFF`, radius `--radius-card` (21.6px), shadow `--shadow-hero`. Inner padding ≈ 48–56px.
- Card content is **center-aligned** as a vertical stack, except the final action row.
- Vertical stack order (top → bottom), centered:
  1. **Icon tile** — rounded-square tile (≈ 64×64, radius `--radius-lg` 12px) with a faint tint fill and a 1px hairline; contains an outline **envelope/mail icon** in `--bari-green`. A very soft duplicate glyph sits behind it (subtle depth) — optional.
  2. **Eyebrow** — `BARI INTELLIGENCE UPDATES`, style `.bari-eyebrow` (Geist Mono, 700, ~0.65rem, uppercase, letter-spacing 0.24em, color = green @ ~80%). Margin-top ≈ 20px.
  3. **Heading** — `הצטרפו לקהילה שבוחרת טוב יותר`, style `.bari-h1`/display-ish (Inter/Heebo, 800, ~2rem, line-height 1.12, letter-spacing −0.05em, color `--fg1`). Margin-top ≈ 10px.
  4. **Lead** — `ניתוחים, דירוגים והשוואות מזון ישירות למייל.`, style `.bari-lead` but sized ~1rem, color `--fg2`/`--fg3`. Margin-top ≈ 10px.
  5. **Action row** — margin-top ≈ 28px. See below.
  6. **Footnote** — `ללא ספאם. ביטול בכל עת.`, style `.bari-footnote`-ish, color `--fg3`, centered, margin-top ≈ 16px.

**Action row (the key composition)**
- A horizontal row, **RTL order** (reading right→left): **email input** (right) → **submit button** (left).
- **Olive mascot** stands to the **left** of the button, overlapping/adjacent, feet roughly on the row baseline. Height ≈ 120–130px. Asset: `assets/mascot-olive.png` (transparent PNG). It is decorative — `aria-hidden`, `pointer-events:none`, and it should not push the input's usable width.
- **Email input:** flex-grows to fill available width (in the reference ≈ 400px). Height ≈ 56px, background `--surface`, 1px `--hairline` border, radius `--radius-pill` (fully rounded), horizontal padding ≈ 22px. Placeholder `you@example.com` in `--fg3`. Focus: border → `--green-ring`, subtle green focus ring.
- **Submit button:** label `הירשמו לניוזלטר`. Height ≈ 56px, background `--bari-green #1F8F6A`, text white, weight 600–700, radius `--radius-pill`, horizontal padding ≈ 26px, shadow `--shadow-cta`. Hover: darken slightly toward `--bari-green-deep #176F53` and lift. Active: settle.

**Interactions**
- Standard email validation on submit (required, valid email format). On invalid, show inline error using `--destructive #B42318`.
- Success state: replace the row with a confirmation message (copy TBD by product) — not shown in reference.
- Mascot is static (no animation required); an optional gentle bob on hover of the card is a nice-to-have, not required.

---

## Screen 2d — "Comparisons from the shelf" Section

**Purpose:** a homepage/section block that introduces supermarket product comparisons and links into them. Leaf mascot gives the section personality.

**Layout**
- Section on `--canvas`, content max-width ≈ `--content-max` (1120px), centered.
- **Header block** (RTL, right-aligned text):
  - Sits at the **top-right**; the **leaf mascot** floats at the **top-left** of the header, height ≈ 150px. Asset: `assets/mascot-leaf.png` (transparent PNG, leaf holding a magnifier). Decorative — `aria-hidden`.
  - **Eyebrow** — `BARI COMPARISONS`, `.bari-eyebrow` (green mono uppercase, tracking 0.24em), right-aligned.
  - **Title** — `השוואות מהמדף`, `.bari-h2` (Inter/Heebo 800, ~1.875rem, letter-spacing −0.04em, `--fg1`), right-aligned, margin-top ≈ 8px.
  - **Lead paragraph** — right-aligned, `.bari-body`/`.bari-lead` at ~0.95rem, color `--fg2`, max-width ≈ 640px, margin-top ≈ 12px. Copy:
    `באריי בודקת מוצרים אמיתיים מהסופרמרקט ובתי המרקחת כדי לתת לכם חווית השוואה אינטראקטיבית בין מוצרים. כל דף השוואה בוחן מוצרים דומים לפי פרמטרים מוגדרים מראש על ידי אלגוריתם מכונה לומדת ומציג חסרונות ויתרונות בהקשר הנכון.`
- **Card grid:** 2 columns × 2 rows, `display:grid`, `gap` ≈ 24px, margin-top ≈ 34px. On narrow widths collapse to 1 column.

**Row 1 — "Active comparisons" (2 elevated cards)**
Each card: background `--surface #FFFFFF`, radius `--radius-xl` (14px), 1px `--hairline`, shadow `--shadow-card`, padding ≈ 24–28px, RTL right-aligned content.
- **Status badge** (top-right corner of card): pill, label `זמין`, `.bari-mono`-ish small caps. Card A uses **green** (bg `--grade-a-bg #E8F5EF`, text `--grade-a-text #176F53`); Card B uses **terracotta** (bg `--grade-d-bg #FDECE8`, text `--grade-d-text #A63F2A`).
- **Kicker line**: `השוואות פעילות` + a lighter category tail. Colored to match the card accent (green for A, terracotta for B), weight 700, ~0.95rem.
- **Title** (`.bari-h3`, 800, `--fg1`):
  - Card A: `תוספי תזונה — ספיגה ואפקטיביות, לא רק מה שעל הקפסולה`
  - Card B: `מה שכתוב על האריזה — ומה שכתוב ברכיבים`
- **Body** (`.bari-body`, `--fg2`):
  - Card A: `תוספי תזונה מנותחים באופן שונה ממוצרי מזון — ספיגה, אפקטיביות ועוד`
  - Card B: `מוצרי סופרמרקט: חלב, לחם, חטיפים, עוגות, גבינות ועוד`
- **CTA pill** (bottom, aligned to start/right): label `לכל ההשוואות` + a chevron `‹`. Filled pill, radius `--radius-pill`, text white. Card A green `--bari-green`; Card B terracotta `--grade-d-text #A63F2A`. Hover: darken + lift.

**Row 2 — "Coming soon" (2 muted cards)**
Each card: background `--surface-2 #F9F9F9` (flat, no elevation), radius `--radius-xl`, 1px `--hairline-soft`, padding ≈ 24–28px, RTL. Visually recessed vs. row 1.
- **Status badge** (top-right): pill `בקרוב`, neutral — bg `--chip-bg`/light grey, text `--fg3`.
- **Title with clock icon** (`.bari-h3`, `--fg1`), a small outline clock glyph in `--fg3` beside it:
  - Card C: `טיפוח אישי`
  - Card D: `מזון גולמי`
- **Body** (`.bari-body`, `--fg3` — muted, since coming soon):
  - Card C: `קרמים, שמפו ומוצרי טיפוח — ניתוח מרכיבים ותוויות, כמו בכל קטגוריה אחרת.`
  - Card D: `ירקות, פירות, דגנים וקטניות — לפני שמישהו אורז אותם.`
- No CTA button on coming-soon cards.

**Section footer**
- A right/end-aligned back link: `חזרה לדף הבית` with a leading `←`, style `.bari-meta`, color `--fg3`, hover → `--fg2`. Margin-top ≈ 16px.

**Interactions**
- Active cards: entire card is clickable → navigates to the comparison category. CTA pill is the affordance; hover lifts the card (`--shadow-lift`) and darkens the CTA.
- Coming-soon cards: non-interactive (or a disabled/tooltip "בקרוב" state).
- Optional entrance: reveal-up on scroll using `--ease-out-soft` over `--dur-reveal` (840ms), staggered per card.

---

## Design Tokens
Full source in `tokens/colors_and_type.css`. The values used across these two screens:

**Color**
- `--bari-green #1F8F6A` — CTAs, eyebrow, green accents
- `--bari-green-deep #176F53` — green hover / grade-A text
- `--fg1 #111318` — headings
- `--fg2 #4E5663` — body copy
- `--fg3 #7A817C` — meta, muted body, placeholder, footnote
- `--canvas #F7F7F2` — page canvas
- `--surface #FFFFFF` — cards (active), input
- `--surface-2 #F9F9F9` — coming-soon cards
- `--chip-bg #F7F7F2` — neutral badge bg
- `--hairline rgba(17,19,24,0.08)` / `--hairline-soft rgba(17,19,24,0.06)` — borders
- `--green-ring rgba(31,143,106,0.25)` — focus/hover border
- Terracotta accent: `--grade-d-bg #FDECE8`, `--grade-d-text #A63F2A`
- Green accent tint: `--grade-a-bg #E8F5EF`, `--grade-a-text #176F53`
- `--destructive #B42318` — form errors

**Type** (families load via `next/font` in production; CDN import in the token file for reference)
- `--font-sans` / `--font-heading`: `"Inter", "Heebo", …` — Inter for Latin, Heebo for Hebrew
- `--font-mono`: `"Geist Mono", "Heebo", …` — eyebrows, badges, tabular numbers
- Scale used: `.bari-eyebrow` (mono .65rem/0.24em), `.bari-h1` (800, ~2rem/−0.05em), `.bari-h2` (800, ~1.875rem/−0.04em), `.bari-h3` (800, 1.125rem/−0.02em), `.bari-lead` (400, 1.125rem/1.7), `.bari-body` (400, .9375rem/1.7), `.bari-footnote` (.625rem)

**Radii:** `--radius-pill 9999px` (buttons, input, badges), `--radius-lg 12px` (icon tile), `--radius-xl 14px` (cards), `--radius-card 21.6px` (newsletter card)

**Shadows:** `--shadow-card` (resting cards), `--shadow-lift` (card hover), `--shadow-hero` (newsletter card), `--shadow-cta` (green CTA)

**Motion:** `--ease-out-soft cubic-bezier(0.22,1,0.36,1)`, `--dur 500ms`, `--dur-reveal 840ms`

---

## Assets
In `assets/`:
- `mascot-olive.png` — "Little Olive" standing pose (transparent PNG). Used in **2b**. Decorative.
- `mascot-leaf.png` — "Curious Leaf" holding a magnifier (transparent PNG). Used in **2d**. Decorative.

Both are AI-generated brand mascot renders already used in the Bari prototype. Treat as decorative (`aria-hidden`). If the production app has vector/optimized versions of these mascots, prefer those. The **mail icon** (2b) and **clock/chevron icons** (2d) are standard outline icons — use the codebase's existing icon set (e.g. lucide) rather than these images.

## Reference Renders
In `references/`:
- `2b-newsletter-signup.png` — full render of screen 2b
- `2d-comparisons-section.png` — full render of screen 2d

These are the source of truth for layout and spacing. Measurements above are derived from them and are approximate where noted (≈).

## Files
These screens originate from the prototype `Bari Characters - Planted.dc.html` (items `#2b` and `#2d`) in the design project. The RTL Hebrew copy, token names, and mascot placement there match this README.
